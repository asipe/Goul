var searchData=
[
  ['watch',['Watch',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1FilesResource.html#a37e80709adacf60271d19ac8426a8d98',1,'Google::Apis::Drive::v2::FilesResource.Watch()'],['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1ChangesResource.html#a076fb2fd459adc1c4c197a175ee249c9',1,'Google::Apis::Drive::v2::ChangesResource.Watch()']]]
];

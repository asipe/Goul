var searchData=
[
  ['realtimeresource',['RealtimeResource',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1RealtimeResource.html',1,'Google::Apis::Drive::v2']]],
  ['repliesresource',['RepliesResource',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1RepliesResource.html',1,'Google::Apis::Drive::v2']]],
  ['revision',['Revision',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1Data_1_1Revision.html',1,'Google::Apis::Drive::v2::Data']]],
  ['revisionlist',['RevisionList',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1Data_1_1RevisionList.html',1,'Google::Apis::Drive::v2::Data']]],
  ['revisionsresource',['RevisionsResource',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1RevisionsResource.html',1,'Google::Apis::Drive::v2']]],
  ['rolesetsdata',['RoleSetsData',['../classGoogle_1_1Apis_1_1Drive_1_1v2_1_1Data_1_1About_1_1AdditionalRoleInfoData_1_1RoleSetsData.html',1,'Google::Apis::Drive::v2::Data::About::AdditionalRoleInfoData']]]
];

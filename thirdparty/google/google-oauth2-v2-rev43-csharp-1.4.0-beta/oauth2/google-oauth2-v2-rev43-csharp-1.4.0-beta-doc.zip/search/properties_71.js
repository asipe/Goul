var searchData=
[
  ['quotauser',['QuotaUser',['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1UserinfoResource_1_1V2Resource_1_1MeResource_1_1GetRequest.html#a9dac426a1f59cea15ffaa84fcf059468',1,'Google::Apis::Oauth2::v2::UserinfoResource::V2Resource::MeResource::GetRequest.QuotaUser()'],['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1UserinfoResource_1_1GetRequest.html#aea2f4fef4c30db3690a5e78b7901180c',1,'Google::Apis::Oauth2::v2::UserinfoResource::GetRequest.QuotaUser()'],['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1Oauth2Service_1_1TokeninfoRequest.html#a1a88c9539760e550aa339e5ed47ce171',1,'Google::Apis::Oauth2::v2::Oauth2Service::TokeninfoRequest.QuotaUser()']]]
];

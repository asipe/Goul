var searchData=
[
  ['userinfo',['Userinfo',['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1Data_1_1Userinfo.html',1,'Google::Apis::Oauth2::v2::Data']]],
  ['userinforesource',['UserinfoResource',['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1UserinfoResource.html',1,'Google::Apis::Oauth2::v2']]]
];

var searchData=
[
  ['v2resource',['V2Resource',['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1UserinfoResource_1_1V2Resource.html',1,'Google::Apis::Oauth2::v2::UserinfoResource']]],
  ['verified_5femail',['Verified_email',['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1Data_1_1Userinfo.html#a29911dce1a386720d5f7c79307c5ccb0',1,'Google::Apis::Oauth2::v2::Data::Userinfo.Verified_email()'],['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1Data_1_1Tokeninfo.html#a3608b567ab85da097960e6bdded61260',1,'Google::Apis::Oauth2::v2::Data::Tokeninfo.Verified_email()']]]
];

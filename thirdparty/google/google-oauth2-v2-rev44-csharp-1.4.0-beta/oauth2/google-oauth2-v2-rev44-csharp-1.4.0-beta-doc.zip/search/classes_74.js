var searchData=
[
  ['tokeninfo',['Tokeninfo',['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1Data_1_1Tokeninfo.html',1,'Google::Apis::Oauth2::v2::Data']]],
  ['tokeninforequest',['TokeninfoRequest',['../classGoogle_1_1Apis_1_1Oauth2_1_1v2_1_1Oauth2Service_1_1TokeninfoRequest.html',1,'Google::Apis::Oauth2::v2::Oauth2Service']]]
];
